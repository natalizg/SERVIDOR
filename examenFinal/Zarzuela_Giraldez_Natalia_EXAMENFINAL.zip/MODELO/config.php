<?php
    define('DB_HOST', 'localhost');
    define('DB_USER', 'RESTAURANTE');
    define('DB_PASSWORD', 'userUSER2');
    define('DB_NAME', 'RESTAURANTE');
?>