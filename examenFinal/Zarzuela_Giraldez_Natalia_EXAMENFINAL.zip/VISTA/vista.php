<div class = "contenedor-login">
    <div class="title">
        <h2>Bienvenido a SUSHI</h2>
    </div>
    <div class="interior">
        <form class = "menu-inicio" action="index.php" method="post">
            <button type="submit" name="opcion" value="cliente">Cliente</button>
            <button type="submit" name="opcion" value="personal">Personal</button>
        </div>
    </div>
</div>